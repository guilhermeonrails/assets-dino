let floor;
let xfloor = 0;
let bgImg;
let xBg = 0
let dinoImages = [];
let currentDinoImage = 0;
let cloudsImg
let xClouds = 0

function preload() {
  floor = loadImage('assets/bg.png');
  bgImg = loadImage('assets/bg.jpeg')
  cloudsImg = loadImage('assets/cloud.png')
  for (let i = 1; i <= 8; i++) {
    dinoImages.push(loadImage(`assets/dino/${i}.png`));
  }
}

function setup() {
  createCanvas(500, 200);
}

function draw() {
  moverBg()
  moverChao();
  nuvens()
  adicionarDino();
}

function adicionarDino() {
  clear();
  moverBg()
  moverChao();
  nuvens()
  image(dinoImages[currentDinoImage], 30, 110, 60, 60);
  if (frameCount % 4 === 0) {
    currentDinoImage = (currentDinoImage + 1) % dinoImages.length;
  }
}

function moverChao() {
  image(floor, xfloor, 0, width, height);
  image(floor, xfloor + width, 0, width, height);

  xfloor -= 2;
  if (xfloor <= -width) {
    xfloor = 0;
  }
}


function moverBg() {
  image(bgImg, xBg, 0, width, height-30);
  image(bgImg, xBg + width, 0, width, height-30);
  
  xBg -= 0.08
  if (xBg <= -width) {
    xBg = 0;
  }
}

function nuvens() {
  tint(255, 150);
  image(cloudsImg, xClouds + width, 15, width/15, height/12);
  noTint();
  
  xClouds -= 0.2
  if (xClouds <= -width - 200) {
    xClouds = 0;
  }
}
